const DB_URL = 'https://arrgregator.bruff.xyz/all.ndjson';

async function updateCounter() {
  const el = document.getElementById('count');
  try {
    const lines = (await (await fetch(DB_URL)).text())
      .trim().split('\n').filter(Boolean);
    el.textContent = `(${lines.length})`;
  } catch {
    el.textContent = '(?)';
  }
}

window.addEventListener('DOMContentLoaded', () => {
  updateCounter();
  setInterval(updateCounter, 5000);

  document.getElementById('stumble').addEventListener('click', () => {
    const mode = document.getElementById('mode').value;
    chrome.runtime.sendMessage({ action: 'openRandom', mode });
  });

  document.getElementById('manage').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
});

