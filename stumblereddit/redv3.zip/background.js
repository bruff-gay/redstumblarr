/* global browser */

const DB_URL      = 'https://raw.githubusercontent.com/bruff-gay/redlistjson/refs/heads/main/all.ndjson';
const STORAGE_KEY = 'offlineDB';

/* ---------- 1.  DB helpers ---------- */
async function getDB() {
  const store = (await browser.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
  if (store?.data) return store.data;
  return fetchAndCacheDB();
}

async function fetchAndCacheDB() {
  try {
    const res  = await fetch(DB_URL);
    if (!res.ok) throw new Error('network');
    const text = await res.text();
    const data = text.trim().split('\n').filter(Boolean).map(JSON.parse);
    await browser.storage.local.set({
      [STORAGE_KEY]: { data, etag: res.headers.get('etag') || '' }
    });
    return data;
  } catch (e) {
    console.warn('[StumbleReddit] network fetch failed – using bundled snapshot');
    return fetchBundledSnapshot();
  }
}

async function fetchBundledSnapshot() {
  const url  = browser.runtime.getURL('_data/snapshot.ndjson');
  const text = await (await fetch(url)).text();
  const data = text.trim().split('\n').filter(Boolean).map(JSON.parse);
  await browser.storage.local.set({ [STORAGE_KEY]: { data, etag: '' } });
  return data;
}

/* ---------- 2.  messaging ---------- */
browser.runtime.onMessage.addListener(async (msg) => {
  if (msg.action === 'openRandom') {
    const db   = await getDB();
    const list = filterDB(db, msg.mode);
    if (!list.length) return;
    const pick = list[Math.floor(Math.random() * list.length)];
    browser.tabs.create({ url: `https://www.reddit.com/r/${pick.name}` });
  }
});

/* ---------- 3.  context menu ---------- */
browser.runtime.onInstalled.addListener(() => {
  browser.contextMenus.create({ id: 'stumble', title: 'Random subreddit', contexts: ['all'] });
});
browser.contextMenus.onClicked.addListener(async () => {
  const db   = await getDB();
  const list = filterDB(db, 'all');
  if (list.length) {
    const pick = list[Math.floor(Math.random() * list.length)];
    browser.tabs.create({ url: `https://www.reddit.com/r/${pick.name}` });
  }
});

/* ---------- 4.  helpers ---------- */
function filterDB(db, mode) {
  if (mode === 'sfw')      return db.filter(r => !r.nsfw);
  if (mode === 'nsfw')     return db.filter(r => r.nsfw && !r.creator);
  if (mode === 'creators') return db.filter(r => r.creator);
  return db;
}
